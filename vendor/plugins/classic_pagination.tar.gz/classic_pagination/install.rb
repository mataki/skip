puts "\n\n" + File.read(File.dirname(__FILE__) + '/README')
