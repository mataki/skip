require File.dirname(__FILE__) + '/../spec_helper'

describe "A sample spec" do
  it "should pass" do
    true.should === true
  end
end