module ViewSpecHelper
  def method_in_helper
    "<div>This is text from a method in the ViewSpecHelper</div>"
  end

  def method_in_template_with_partial
    "<div>method_in_template_with_partial in ViewSpecHelper</div>"
  end

  def method_in_partial
    "<div>method_in_partial in ViewSpecHelper</div>"
  end
end
