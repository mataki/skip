module Spec
  module Example
    class ExamplePendingError < StandardError
    end

    class PendingExampleFixedError < StandardError
    end
  end
end
