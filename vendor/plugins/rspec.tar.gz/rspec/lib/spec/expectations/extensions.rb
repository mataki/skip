require 'spec/expectations/extensions/object'
require 'spec/expectations/extensions/string_and_symbol'
