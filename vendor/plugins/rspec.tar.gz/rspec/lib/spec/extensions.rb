require 'spec/extensions/object'
require 'spec/extensions/class'
require 'spec/extensions/main'
