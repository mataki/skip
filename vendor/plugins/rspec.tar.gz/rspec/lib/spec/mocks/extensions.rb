require 'spec/mocks/extensions/object'
