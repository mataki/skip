require 'spec/story/extensions/main'
require 'spec/story/extensions/string'
require 'spec/story/extensions/regexp'
