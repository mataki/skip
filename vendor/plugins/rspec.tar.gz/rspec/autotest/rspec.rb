require File.dirname(__FILE__) + "/../lib/autotest/rspec.rb"
