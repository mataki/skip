$: << File.dirname(__FILE__)
require 'life/game'
require 'life/grid'
