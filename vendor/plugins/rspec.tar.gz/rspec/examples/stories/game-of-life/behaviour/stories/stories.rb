require File.join(File.dirname(__FILE__), *%w[helper])
require 'behaviour/stories/create_a_cell'
require 'behaviour/stories/kill_a_cell'
