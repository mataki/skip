require 'spec'
require 'behaviour/examples/game_behaviour'
require 'behaviour/examples/grid_behaviour'
