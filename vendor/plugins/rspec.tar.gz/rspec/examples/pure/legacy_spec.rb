require File.dirname(__FILE__) + '/spec_helper'
context "A legacy spec" do
  setup do
  end
  
  specify "should work fine" do
  end
  
  teardown do
  end
end
