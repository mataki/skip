require "pre_commit/pre_commit"
require "pre_commit/rspec"
require "pre_commit/core"
require "pre_commit/rspec_on_rails"
