describe "This example" do
  
  before(:each) do
    NonExistentClass.new
  end
  
  it "should be listed as failing in setup" do
  end
  
end
